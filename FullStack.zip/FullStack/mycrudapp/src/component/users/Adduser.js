import axios from "axios";
import {useNavigate} from "react-router-dom";
import { React, useState } from "react";

const Adduser =()=>{

    let navigate = useNavigate();

    const [user, setUser] = useState ({
        name:"",
        email:"",
        phone:"",
        userType:"",
    });

    const{name, email, phone, userType} = user;
    const onInputChange = e => {
        setUser({...user,[e.target.name]:e.target.value});
    };

    const onSubmit= async e =>{
        e.preventDefault();
        user.phone=parseInt(user.phone);
        user.id=0;
        await axios.post("https://localhost:7092/api/User/userAdd", user);
        navigate("/");
    }

    return (
        <div className="container">
          <div className="w-75 mx-auto shadow p-5">
            <h2 className="text-center mb-4">Add A User</h2>
            <form onSubmit={e => onSubmit(e)}>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control form-control-m mt-2"
                  placeholder="Enter Your Name"
                  name="name"
                  value={name}
                  onChange={e => onInputChange(e)}
                />
              </div>
              <div className="form-group">
                <input
                  type="email"
                  className="form-control form-control-m mt-2"
                  placeholder="Enter Your E-mail Address"
                  name="email"
                  value={email}
                  onChange={e => onInputChange(e)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control form-control-m mt-2"
                  placeholder="Enter Your Phone Number"
                  name="phone"
                  value={phone}
                  onChange={e => onInputChange(e)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control form-control-m mt-2"
                  placeholder="Enter Your Class"
                  name="userType"
                  value={userType}
                  onChange={e => onInputChange(e)}
                />
              </div>
              <button className="btn btn-primary btn-block mt-2">Add User</button>
            </form>
          </div>
        </div>
      );
    };

export default Adduser;