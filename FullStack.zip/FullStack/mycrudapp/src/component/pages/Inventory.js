import React, {useState, useEffect} from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const Inventory = () => {
    const [inventory, setInventory] = useState([]);
    
    useEffect(()=>{
        loadInventory();
    },[]);

    const loadInventory = async () =>{
        const result = await axios.get("https://localhost:7092/api/Inventory/inventoryGetAll");
        setInventory(result.data);
    };

    const deleteInventory = async id =>{
        await axios.delete(`https://localhost:7092/api/Inventory/${id}`);
        loadInventory();
    }

    return (
      <div className="container">
        <div className="py-4">
          <h1>Inventory</h1>
                <table className="table">
                    <thead>
                        <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">User Id</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                       {inventory.map((inventory, index)=>(
                        <tr>
                            <th scope="row">{index + 1}</th>
                            <td>{inventory.name}</td>
                            <td>{inventory.quantity}</td>
                            <td>{inventory.userId}</td>
                            <td>
                                <Link className="btn btn-outline-warning m-2" to={`/inventory/edit/${inventory.id}`}><i className="fa-regular fa-pen-to-square"></i></Link>
                                <Link className="btn btn-danger m-2" onClick={()=>{deleteInventory(inventory.id)}}>Delete</Link>
                            </td>
                        </tr>
                       ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default Inventory;