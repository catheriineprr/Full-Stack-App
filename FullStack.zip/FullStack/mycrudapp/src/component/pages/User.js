import React, {useState, useEffect} from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const User = () => {

    const [users, setUsers] = useState([]);
    
    useEffect(()=>{
        loadUser();
    },[]);

    const loadUser = async () =>{
        const result = await axios.get("https://localhost:7092/api/User/userGetAll");
        setUsers(result.data);
    };

    const deleteUser = async id =>{
        await axios.delete(`https://localhost:7092/api/User/${id}`);
        loadUser();
    }

    return(
        <div className="container">
            <div className="py-4" >
                <h1>User</h1>
                <table className="table">
                    <thead>
                        <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                       {users.map((users, index)=>(
                        <tr>
                            <th scope="row">{index + 1}</th>
                            <td>{users.name}</td>
                            <td>{users.email}</td>
                            <td>{users.phone}</td>
                            <td>
                                <Link className="btn m-2" to={`/inventory/${users.id}`}><i className="fa-solid fa-eye"></i></Link>
                                <Link className="btn btn-outline-warning m-2" to={`/user/edit/${users.id}`}><i className="fa-regular fa-pen-to-square"></i></Link>
                                <Link className="btn btn-danger m-2" onClick={()=>{deleteUser(users.id)}}>Delete</Link>
                            </td>
                        </tr>
                       ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default User;