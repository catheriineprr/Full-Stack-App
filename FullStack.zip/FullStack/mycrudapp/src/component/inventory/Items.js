import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import axios from "axios";

const Items = () => {
  const [inventory, setInventory] = useState({
    id:"",
    name:"",
    quantity:""
  });
  const { id } = useParams();
  useEffect(() => {
    loadInventory();
  }, []);
  const loadInventory = async () => {
    const res = await axios.get(`https://localhost:7092/api/Inventory/inventoryGetByUser/${id}`);
    setInventory(res.data);
  };
  return (
    <div className="container py-4">
      <Link className="btn btn-primary" to="/">
        back to users
      </Link>
      <h1 className="display-4">User Id: {id}</h1>
      <hr />
      <ul className="list-group w-50">
        <li className="list-group-item">Item Id: {inventory.id}</li>
        <li className="list-group-item">Item name: {inventory.name}</li>
        <li className="list-group-item">Quantity: {inventory.quantity}</li>
      </ul>
    </div>
  );
};

export default Items;