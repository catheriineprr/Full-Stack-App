import axios from "axios";
import {useNavigate} from "react-router-dom";
import { React, useState } from "react";

const AddInventory =()=>{

    let navigate = useNavigate();

    const [inventory, setInventory] = useState ({
        name:"",
        quantity:"",
        userID:"",
    });

    const{name, quantity, userID} = inventory;
    const onInputChange = e => {
        setInventory({...inventory,[e.target.name]:e.target.value});
    };

    const onSubmit= async e =>{
        e.preventDefault();
        await axios.post ("https://localhost:7092/api/Inventory/inventoryAdd", inventory);
        navigate("/");
    }
    return (
        <div className="container">
          <div className="w-75 mx-auto shadow p-5">
            <h2 className="text-center mb-4">Add An Item</h2>
            <form onSubmit={e => onSubmit(e)}>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control form-control-m mt-2"
                  placeholder="Enter The Item's Name"
                  name="name"
                  value={name}
                  onChange={e => onInputChange(e)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control form-control-m mt-2"
                  placeholder="Enter The quantity"
                  name="quantity"
                  value={quantity}
                  onChange={e => onInputChange(e)}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control form-control-m mt-2"
                  placeholder="Enter The User ID"
                  name="userID"
                  value={userID}
                  onChange={e => onInputChange(e)}
                />
              </div>
              <button className="btn btn-primary btn-block mt-2">Add Item</button>
            </form>
          </div>
        </div>
      );
    };

export default AddInventory;