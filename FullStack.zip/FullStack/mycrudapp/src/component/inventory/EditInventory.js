import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

const EditInventory = () => {

  let navigate = useNavigate();
  const { id } = useParams();
  const [inventory, setInventory] = useState({
    name: "",
    quantity: "",
    userId: ""
  });

  const { name, quantity, userId } = inventory;
  const onInputChange = e => {
    setInventory({ ...inventory, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    loadInventory();
  }, []);

  const onSubmit = async e => {
    e.preventDefault();
    inventory.quantity=parseInt(inventory.quantity);
    await axios.put(`https://localhost:7092/api/Inventory/inventoryUpdate`, inventory);
    navigate("/");
  };

  const loadInventory = async () => {
    const result = await axios.get(`https://localhost:7092/api/Inventory/inventoryGet/${id}`);
    setInventory(result.data);
  };
  return (
    <div className="container">
      <div className="w-75 mx-auto shadow p-5">
        <h2 className="text-center mb-4">Edit An Item</h2>
        <form onSubmit={e => onSubmit(e)}>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-m p-2"
              placeholder="Enter The Name"
              name="name"
              value={name}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-m mt-2"
              placeholder="Enter The Quantity"
              name="quantity"
              value={quantity}
              onChange={e => onInputChange(e)}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control form-control-m mt-2"
              placeholder="Enter The User ID"
              name="userId"
              value={userId}
              onChange={e => onInputChange(e)}
            />
          </div>
          <button className="btn btn-warning btn-block mt-2">Update Item</button>
        </form>
      </div>
    </div>
  );
};

export default EditInventory;