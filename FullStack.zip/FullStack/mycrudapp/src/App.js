import "../node_modules/bootstrap/dist/css/bootstrap.css"
import User from "./component/pages/User"
import Navbar from "./component/layout/Navbar"
import Inventory from "./component/pages/Inventory"
import Adduser from "./component/users/Adduser"
import Edituser from "./component/users/Edituser"
import Items from "./component/inventory/Items"
import AddInventory from "./component/inventory/AddInventory"
import EditInventory from "./component/inventory/EditInventory"
import {Route, Routes} from "react-router-dom";


export function App() {
  return (
    <>
      <Navbar />
        <Routes>
          <Route path="/" element={<User />}></Route>
          <Route path="/inventory" element={<Inventory />}></Route>
          <Route path="/user/add" element={<Adduser/>}></Route>
          <Route path="/user/edit/:id" element={<Edituser/>}></Route>
          <Route path="/inventory/:id" element={<Items/>}></Route>
          <Route path="/inventory/add" element={<AddInventory/>}></Route>
          <Route path="/inventory/edit/:id" element={<EditInventory/>}></Route>
        </Routes>
    </>
  )
}

export default App;
