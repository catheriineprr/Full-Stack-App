﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using User_inventory.Models;
using User_inventory.Services;

namespace User_inventory.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class InventoryController : ControllerBase
    {

        private IInventoryService _inventoryService;

        public InventoryController(IInventoryService inventoryService)
        {
            _inventoryService = inventoryService;
        }

        [HttpPost("inventoryAdd")]
        public ActionResult<List<Inventory>> InventoryAdd(Inventory newInventory)
        {
            _inventoryService.InventoryAdd(newInventory);
            return Ok();
        }

        [HttpGet("inventoryGet/{id}")]
        public ActionResult<Inventory> InventoryGet(int id)
        {
            return Ok(_inventoryService.InventoryGet(id));
        }

        [HttpGet("inventoryGetAll")]
        public ActionResult<List<Inventory>> InventoryGetAll()
        {
            return Ok(_inventoryService.InventoryGetAll());
        }

        [HttpGet("inventoryGetByUser/{id}")]
        public ActionResult<List<Inventory>> InventoryGetByUser(int id)
        {
            return Ok(_inventoryService.InventoryGetByUser(id));
        }

        [HttpPut("inventoryUpdate")]
        public ActionResult InventoryUpdate(Inventory newInventory)
        {
            _inventoryService.InventoryUpdate(newInventory);
            return Ok();
        }

        [HttpDelete("{id}")]
        public ActionResult InventoryDelete(int id)
        {
            _inventoryService.InventoryDelete(id);
            return Ok();
        }

    }
}
