﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using User_inventory.Models;
using User_inventory.Services;

namespace User_inventory.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class UserController : ControllerBase
    {

        private IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("userAdd")]
        public ActionResult<List<User>> UserAdd(User newUser)
        {
            _userService.UserAdd(newUser);
            return Ok();
        }

        [HttpGet("{id}")]
        public ActionResult <User> UserGet(int id)
        {
            return Ok(_userService.UserGet(id));
        }

        [HttpGet("userGetAll")]
        public ActionResult <List<User>> UserGetAll()
        {
            return Ok(_userService.UserGetAll());
        }

        [HttpPut("userUpdate")]
        public ActionResult UserUpdate(User newUser)
        {
            _userService.UserUpdate(newUser);
            return Ok();
        }

        [HttpDelete("{id}")]
        public ActionResult UserDelete(int id)
        {
            _userService.UserDelete(id);
            return Ok();
        }

    }
}
