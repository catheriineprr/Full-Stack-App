﻿using User_inventory.Models;

namespace User_inventory.Services
{
    public interface IUserService
    {
        void UserAdd(User newUser);
        List<User> UserGetAll();
        User UserGet(int id);
        void UserUpdate(User newUser);
        void UserDelete(int id);
    }
}
