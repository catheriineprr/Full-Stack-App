﻿using Microsoft.AspNetCore.Mvc;
using User_inventory.Data;
using User_inventory.Models;

namespace User_inventory.Services
{
    public class InventoryService : IInventoryService
    {
        
        private readonly DataContext _dataContext;
        public InventoryService(DataContext context)
        {
            _dataContext = context;
        }

        public void InventoryAdd (Inventory newInventory)
        {
            _dataContext.Inventories.Add(newInventory);
            _dataContext.SaveChanges();
        }

        public List<Inventory> InventoryGetAll()
        {
            return _dataContext.Inventories.ToList();
        }

        public Inventory InventoryGet(int id)
        {
            return _dataContext.Inventories.FirstOrDefault(u => u.Id == id);
        }

        public Inventory InventoryGetByUser(int id)
        {
            _dataContext.Inventories.Select(u => u.UserId == id);
            return _dataContext.Inventories.Find(id);
        }

        public void InventoryUpdate(Inventory newInventory)
        {
            _dataContext.Inventories.Update(newInventory);
            _dataContext.SaveChanges();
        }


        public void InventoryDelete(int id)
        {
            var deleteItem = _dataContext.Inventories.Find(id);
            _dataContext.Inventories.Remove(deleteItem);
            _dataContext.SaveChanges();
        }

        //public Inventory Trading (int id, UserId, ) 
        // if < 0 
        //context.remove 
    }
}
