﻿using User_inventory.Models;

namespace User_inventory.Services
{
    public interface IInventoryService
    {
        void InventoryAdd(Inventory newInventory);
        List<Inventory> InventoryGetAll();
        Inventory InventoryGet(int id);
        Inventory InventoryGetByUser(int id);
        void InventoryUpdate(Inventory newInventory);
        void InventoryDelete(int id);

    }
}