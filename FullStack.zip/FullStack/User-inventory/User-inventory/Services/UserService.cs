﻿using Microsoft.AspNetCore.Mvc;
using User_inventory.Data;
using User_inventory.Models;

namespace User_inventory.Services
{
    public class UserService : IUserService
    {
        private readonly DataContext _dataContext;
        public UserService(DataContext context)
        {
            _dataContext = context;
        }

        public void UserAdd(User newUser)
        {
            _dataContext.Users.Add(newUser);
            _dataContext.SaveChanges();
        }

        public List<User> UserGetAll()
        {
            return _dataContext.Users.ToList();
        }

        public User UserGet(int id)
        {
            return (_dataContext.Users.FirstOrDefault(u => u.Id == id));
        }


        public void UserDelete(int id)
        {
            var deleteUser = _dataContext.Users.Find(id);
            _dataContext.Users.Remove(deleteUser);
            _dataContext.SaveChanges();
        }

        public void UserUpdate(User newUser)
        {
            _dataContext.Users.Update(newUser);
            _dataContext.SaveChanges();
        }

    }
}
