﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using User_inventory.Models;

namespace User_inventory.Data
{
    public class DataContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Inventory> Inventories { get; set; }
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

    }
}
