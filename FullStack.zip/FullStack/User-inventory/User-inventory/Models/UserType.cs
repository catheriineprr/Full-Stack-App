using System.Text.Json.Serialization;

namespace User_inventory.Models
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum UserType
    {
        Admin = 0,

        User = 1
    }
}